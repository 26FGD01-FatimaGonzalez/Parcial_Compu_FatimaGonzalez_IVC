
import javax.swing.JOptionPane;

/*
 * Préstamo Bancario - Fatima Gonzalez IVC_14
 * Basado en: Java Interfaces Gráficas y Aplicaciones para Internet, pp. 215-236
 */

/**
 * @author lourd
 */
public class JfrmPrestamo extends javax.swing.JFrame {

    // ── Variables de estado ──────────────────────────────────────────────────
    private int    tiposIntrs;
    private int    añosMeses;
    private double credito;
    private int    periodoMax;
    private int    periodoMin;
    private double interesMax;
    private double interesMin;
    private double incremento;
    private double pagoMensual;
    private boolean tablaPagos = false;

    /** Segunda tabla que muestra solo la columna 0 (encabezados de fila: % interés o nº mes) */
    private javax.swing.JTable jtablaCabsFilas;

    private static final java.util.logging.Logger logger =
            java.util.logging.Logger.getLogger(JfrmPrestamo.class.getName());

    // ── initTable ────────────────────────────────────────────────────────────
    /**
     * Crea el modelo de datos compartido entre jtablaPrestamo y jtablaCabsFilas,
     * y los vincula al JScrollPane del diseño visual.
     */
    private void initTable(final int filasTabla, final int colsTabla) {

        // Modelo de datos personalizado
        class CModeloTablaPrestamo extends javax.swing.table.AbstractTableModel {
            Object[][]  dato      = new Object[filasTabla][colsTabla];
            String[]    cabecera  = new String[colsTabla];
            boolean[]   editColum = new boolean[colsTabla];

            CModeloTablaPrestamo() {
                for (int c = 0; c < colsTabla; c++) {
                    cabecera[c]  = "Columna " + c;
                    editColum[c] = (c != 0); // col 0 = solo lectura
                }
            }

            @Override public int    getColumnCount()                          { return cabecera.length; }
            @Override public int    getRowCount()                             { return dato.length; }
            @Override public String getColumnName(int col)                    { return cabecera[col]; }
            @Override public Object getValueAt(int fila, int col)             { return dato[fila][col]; }
            @Override public void   setValueAt(Object obj, int fila, int col) { dato[fila][col] = obj; fireTableCellUpdated(fila, col); }
            @Override public boolean isCellEditable(int f, int c)             { return editColum[c]; }
        }

        // Columnas de la tabla principal: omite la columna 0
        javax.swing.table.TableColumnModel modeloColums =
                new javax.swing.table.DefaultTableColumnModel() {
            boolean primera = true;
            @Override public void addColumn(javax.swing.table.TableColumn col) {
                if (primera) { primera = false; return; }
                col.setMinWidth(110);
                super.addColumn(col);
            }
        };

        // Columnas de la tabla de cabeceras: solo conserva la columna 0
        javax.swing.table.TableColumnModel modeloCabsFilas =
                new javax.swing.table.DefaultTableColumnModel() {
            boolean primera = true;
            @Override public void addColumn(javax.swing.table.TableColumn col) {
                if (primera) {
                    col.setMaxWidth(65);
                    super.addColumn(col);
                    primera = false;
                }
            }
        };

        javax.swing.table.TableModel modeloTabla = new CModeloTablaPrestamo();

        jtablaPrestamo = new javax.swing.JTable(modeloTabla, modeloColums);
        jtablaCabsFilas = new javax.swing.JTable(modeloTabla, modeloCabsFilas);

        jtablaPrestamo.createDefaultColumnsFromModel();
        jtablaCabsFilas.createDefaultColumnsFromModel();

        // Sincronizar selección de filas
        jtablaPrestamo.setSelectionModel(jtablaCabsFilas.getSelectionModel());

        // Estilo de la columna fija
        jtablaCabsFilas.setBackground(java.awt.Color.LIGHT_GRAY);
        jtablaCabsFilas.setSelectionBackground(java.awt.Color.LIGHT_GRAY);

        jtablaPrestamo.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jtablaCabsFilas.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jtablaPrestamo.setFont(new java.awt.Font("Courier New", java.awt.Font.PLAIN, 12));
        jtablaCabsFilas.setFont(new java.awt.Font("Courier New", java.awt.Font.PLAIN, 12));

        // Vincular al JScrollPane
        jScrollPane1.setViewportView(jtablaPrestamo);

        javax.swing.JViewport jv = new javax.swing.JViewport();
        jv.setView(jtablaCabsFilas);
        jv.setPreferredSize(new java.awt.Dimension(65, 1));
        jScrollPane1.setRowHeader(jv);
    }

    // ── Constructor ──────────────────────────────────────────────────────────
    public JfrmPrestamo() {
        initComponents();
        this.setTitle("Préstamo Bancario");
        this.setLocationRelativeTo(null);

        // Valores por defecto
        jtfCredito.setText("6000");
        jtfPeriodoMin.setText("1");
        jtfPeriodoMax.setText("4");
        jtfInteresMin.setText("0.00");
        jtfInteresMax.setText("10.00");
        jcbIncremento.setSelectedIndex(2); // "1.00"

        tiposIntrs = 11; // (10-0)/1 + 1
        añosMeses  =  4; // 4-1+1

        initTable(tiposIntrs, añosMeses + 1); // +1 porque la col 0 es de encabezados

        // Registrar listener UNA SOLA VEZ. initTable reemplaza jtablaPrestamo,
        // así que lo agregamos después de la primera llamada a initTable.
        jtablaPrestamo.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                jtablaPrestamoMouseClicked(e);
            }
        });
    }

    // ── initComponents (generado por NetBeans, NO modificar) ─────────────────
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jtablaPrestamo = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jtfCredito = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jtfPeriodoMax = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jtfPeriodoMin = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jtfInteresMax = new javax.swing.JTextField();
        jtfInteresMin = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jcbIncremento = new javax.swing.JComboBox<>();
        jbtCalculosdePagos = new javax.swing.JButton();
        jbtCalculoAmort = new javax.swing.JButton();
        jmnBar = new javax.swing.JMenuBar();
        jmOpciones = new javax.swing.JMenu();
        jmItemInstruc = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jmItemSalir = new javax.swing.JMenuItem();
        jmnuPrestamoEn = new javax.swing.JMenu();
        jmItemAños = new javax.swing.JMenuItem();
        jmItemMeses = new javax.swing.JMenuItem();
        jmnuAyuda = new javax.swing.JMenu();
        JmItemAcercaDe = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jtablaPrestamo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] { "Title 1", "Title 2", "Title 3", "Title 4" }
        ));
        jScrollPane1.setViewportView(jtablaPrestamo);

        jLabel1.setText("Crédito:");
        jtfCredito.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Duración del préstamo"));
        jLabel2.setText("Máximo");
        jtfPeriodoMax.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jLabel3.setText("Mínimo");
        jtfPeriodoMin.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtfPeriodoMax)
                    .addComponent(jtfPeriodoMin))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtfPeriodoMax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jtfPeriodoMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Tipo de Interés"));
        jLabel4.setText("% máximo:");
        jLabel5.setText("% mínimo:");
        jtfInteresMax.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jtfInteresMin.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jLabel6.setText("Incremento:");
        jcbIncremento.setEditable(true);
        jcbIncremento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0.25", "0.50", "1.00" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtfInteresMin)
                            .addComponent(jtfInteresMax)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jcbIncremento, 0, 138, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(3, 3, 3)
                .addComponent(jtfInteresMax, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(jLabel5)
                .addGap(7, 7, 7)
                .addComponent(jtfInteresMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jcbIncremento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jbtCalculosdePagos.setText("Pagos");
        jbtCalculosdePagos.addActionListener(this::jbtCalculosdePagosActionPerformed);

        jbtCalculoAmort.setText("Amortización");
        jbtCalculoAmort.setEnabled(false);
        jbtCalculoAmort.addActionListener(this::jbtCalculoAmortActionPerformed);

        jmOpciones.setMnemonic('O');
        jmOpciones.setText("Opciones");
        jmItemInstruc.setMnemonic('I');
        jmItemInstruc.setText("Instrucciones");
        jmItemInstruc.addActionListener(this::jmItemInstrucActionPerformed);
        jmOpciones.add(jmItemInstruc);
        jmOpciones.add(jSeparator1);
        jmItemSalir.setMnemonic('S');
        jmItemSalir.setText("Salir");
        jmItemSalir.addActionListener(e -> System.exit(0));
        jmOpciones.add(jmItemSalir);
        jmnBar.add(jmOpciones);

        jmnuPrestamoEn.setMnemonic('P');
        jmnuPrestamoEn.setText("Préstamo en...");
        jmItemAños.setMnemonic('A');
        jmItemAños.setText("Años");
        jmItemAños.addActionListener(this::jmItemAñosActionPerformed);
        jmnuPrestamoEn.add(jmItemAños);
        jmItemMeses.setMnemonic('M');
        jmItemMeses.setText("Meses");
        jmItemMeses.addActionListener(this::jmItemMesesActionPerformed);
        jmnuPrestamoEn.add(jmItemMeses);
        jmnBar.add(jmnuPrestamoEn);

        jmnuAyuda.setMnemonic('y');
        jmnuAyuda.setText("Ayuda");
        JmItemAcercaDe.setMnemonic('A');
        JmItemAcercaDe.setText("Acerca de");
        JmItemAcercaDe.addActionListener(e ->
            JOptionPane.showMessageDialog(this,
                "Préstamo Bancario\nFatima Gonzalez IVC_14",
                "Acerca de", JOptionPane.INFORMATION_MESSAGE));
        jmnuAyuda.add(JmItemAcercaDe);
        jmnBar.add(jmnuAyuda);

        setJMenuBar(jmnBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(jtfCredito))
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jbtCalculosdePagos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jbtCalculoAmort,    javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jtfCredito, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jbtCalculosdePagos)
                .addGap(18, 18, 18)
                .addComponent(jbtCalculoAmort)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // ── Menú: Instrucciones ──────────────────────────────────────────────────
    private void jmItemInstrucActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmItemInstrucActionPerformed
        String msg =
            "Introduzca el crédito, la duración del préstamo y el tipo\n" +
            "de interés. Pulse el botón [Pagos] para visualizar\n" +
            "los pagos mensuales en la rejilla.\n\n" +
            "Elija un pago mensual haciendo clic en una celda y pulse\n" +
            "el botón [Amortización] para ver el plan de amortización.\n\n" +
            "Para copiar datos al portapapeles seleccione las celdas\n" +
            "y pulse Ctrl+C.";
        JOptionPane.showMessageDialog(this, msg, "Instrucciones", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_jmItemInstrucActionPerformed

    // ── Menú: Préstamo en Años ───────────────────────────────────────────────
    private void jmItemAñosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmItemAñosActionPerformed
        jmItemAños.setEnabled(false);
        jmItemMeses.setEnabled(true);
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Años del préstamo"));
    }//GEN-LAST:event_jmItemAñosActionPerformed

    // ── Menú: Préstamo en Meses ──────────────────────────────────────────────
    private void jmItemMesesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmItemMesesActionPerformed
        jmItemAños.setEnabled(true);
        jmItemMeses.setEnabled(false);
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Meses del préstamo"));
    }//GEN-LAST:event_jmItemMesesActionPerformed

    // ── Botón Pagos ──────────────────────────────────────────────────────────
    private void jbtCalculosdePagosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtCalculosdePagosActionPerformed
        // 1. Leer y validar datos del formulario
        try {
            credito    = Double.parseDouble(jtfCredito.getText().trim());
            periodoMin = Integer.parseInt(jtfPeriodoMin.getText().trim());
            periodoMax = Integer.parseInt(jtfPeriodoMax.getText().trim());
            interesMin = Double.parseDouble(jtfInteresMin.getText().trim());
            interesMax = Double.parseDouble(jtfInteresMax.getText().trim());
            String incStr = jcbIncremento.getSelectedItem().toString().replace(',', '.');
            incremento = Double.parseDouble(incStr);

            if (credito <= 0 || periodoMin <= 0 || periodoMax < periodoMin
                    || interesMin < 0 || interesMax < interesMin || incremento <= 0) {
                throw new NumberFormatException("Valores fuera de rango");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Verifique que todos los campos tengan valores numéricos válidos.",
                "Error de datos", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // 2. Calcular dimensiones de la tabla
        tiposIntrs = (int) Math.round((interesMax - interesMin) / incremento) + 1;
        añosMeses  = periodoMax - periodoMin + 1;

        // 3. ¿Estamos en modo "Años"? jmItemAños deshabilitado = modo años activo
        boolean modoAnios = !jmItemAños.isEnabled();
        int factorTiempo  = modoAnios ? 12 : 1;   // si son años, × 12 para obtener meses
        String sufijo     = modoAnios ? " años" : " meses";

        // 4. Reinicializar la tabla con el tamaño correcto (col 0 = encabezado %)
        initTable(tiposIntrs, añosMeses + 1);

        // Re-registrar listener porque initTable crea un nuevo objeto jtablaPrestamo
        jtablaPrestamo.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                jtablaPrestamoMouseClicked(e);
            }
        });

        // 5. Escribir encabezados de columna (col 0 del modelo = columna de filas oculta)
        javax.swing.table.TableModel modelo = jtablaPrestamo.getModel();
        ((javax.swing.table.AbstractTableModel) modelo)
                .fireTableStructureChanged(); // por si acaso

        // Poner nombres de columna en la tabla principal
        for (int col = 0; col < añosMeses; col++) {
            javax.swing.table.TableColumn tc =
                jtablaPrestamo.getColumnModel().getColumn(col);
            tc.setHeaderValue((periodoMin + col) + sufijo);
        }
        jtablaPrestamo.getTableHeader().repaint();

        // Poner cabecera de la columna de filas
        jtablaCabsFilas.getColumnModel().getColumn(0).setHeaderValue("% Int.");
        jtablaCabsFilas.getTableHeader().repaint();

        // 6. Llenar datos
        for (int fila = 0; fila < tiposIntrs; fila++) {
            double interesAnual   = interesMin + fila * incremento;
            double interesMensual = (interesAnual / 100.0) / 12.0;

            // Columna 0 del modelo = encabezado de fila (% interés)
            jtablaCabsFilas.setValueAt(AlinDer("##0.00", interesAnual) + "%", fila, 0);

            for (int col = 0; col < añosMeses; col++) {
                int    totalMeses = (periodoMin + col) * factorTiempo;
                double cuota;

                if (interesMensual == 0.0) {
                    cuota = credito / totalMeses;
                } else {
                    cuota = credito * interesMensual
                            / (1.0 - Math.pow(1.0 + interesMensual, -totalMeses));
                }

                jtablaPrestamo.setValueAt(AlinDer("###,###,##0.00", cuota), fila, col);
            }
        }

        tablaPagos = true;
        jbtCalculoAmort.setEnabled(false); // se activa solo al seleccionar celda
    }//GEN-LAST:event_jbtCalculosdePagosActionPerformed

    // ── Click en la tabla principal ──────────────────────────────────────────
    private void jtablaPrestamoMouseClicked(java.awt.event.MouseEvent evt) {
        if (!tablaPagos) return;

        int fila    = jtablaPrestamo.getSelectedRow();
        int columna = jtablaPrestamo.getSelectedColumn();
        if (fila < 0 || columna < 0) return;

        Object celda = jtablaPrestamo.getValueAt(fila, columna);
        if (celda == null) return;

        // Convertir el String formateado a double
        // Formato: "###,###,##0.00" — separador de miles = ',' y decimal = '.'
        String s = celda.toString().replace(",", "");
        try {
            pagoMensual = Double.parseDouble(s.trim());
            jbtCalculoAmort.setEnabled(true);
        } catch (NumberFormatException ex) {
            // celda vacía o no numérica; ignorar
        }
    }

    // ── Botón Amortización ───────────────────────────────────────────────────
    private void jbtCalculoAmortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtCalculoAmortActionPerformed
        int fila    = jtablaPrestamo.getSelectedRow();
        int columna = jtablaPrestamo.getSelectedColumn();
        if (fila < 0 || columna < 0) return;

        // Leer interés de la cabecera de filas
        String sinteres = jtablaCabsFilas.getValueAt(fila, 0).toString();
        sinteres = sinteres.replace("%", "").replace(",", ".").trim();
        double interesMensual = Double.parseDouble(sinteres) / 100.0 / 12.0;

        // Leer períodos del encabezado de columna
        boolean modoAnios = !jmItemAños.isEnabled();
        int factorTiempo  = modoAnios ? 12 : 1;

        String speriodo = jtablaPrestamo.getColumnModel()
                .getColumn(columna).getHeaderValue().toString();
        speriodo = speriodo.substring(0, speriodo.indexOf(' ')).trim();
        int meses = Integer.parseInt(speriodo) * factorTiempo;

        // Crear tabla de amortización
        int filas = Math.max(meses, 18);
        initTable(filas, 5); // col0=mes, col1=capital, col2=intereses, col3=pendiente, col4=total int.

        // Re-registrar listener después de initTable
        jtablaPrestamo.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                jtablaPrestamoMouseClicked(e);
            }
        });

        // Cabeceras
        jtablaCabsFilas.getColumnModel().getColumn(0).setHeaderValue("Mes");
        String[] cab = { "Capital amort.", "Intereses", "Capital pendiente", "Total intereses" };
        for (int c = 0; c < 4; c++) {
            jtablaPrestamo.getColumnModel().getColumn(c).setHeaderValue(cab[c]);
        }
        jtablaPrestamo.getTableHeader().repaint();
        jtablaCabsFilas.getTableHeader().repaint();

        // Calcular y llenar filas
        double creditoPendiente = credito;
        double totalIntereses   = 0;
        String fmt = "###,###,##0.00";

        for (int mes = 0; mes < meses; mes++) {
            double interesMes    = creditoPendiente * interesMensual;
            double capitalAmort  = pagoMensual - interesMes;
            creditoPendiente    -= capitalAmort;
            totalIntereses      += interesMes;

            jtablaCabsFilas.setValueAt(AlinDer("#####", mes + 1),         mes, 0);
            jtablaPrestamo.setValueAt(AlinDer(fmt, capitalAmort),          mes, 0);
            jtablaPrestamo.setValueAt(AlinDer(fmt, interesMes),            mes, 1);
            jtablaPrestamo.setValueAt(AlinDer(fmt, Math.max(0, creditoPendiente)), mes, 2);
            jtablaPrestamo.setValueAt(AlinDer(fmt, totalIntereses),        mes, 3);
        }

       
        jbtCalculoAmort.setEnabled(false);
         tablaPagos = false;
    }//GEN-LAST:event_jbtCalculoAmortActionPerformed

    // ── main ─────────────────────────────────────────────────────────────────
    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info :
                    javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(() -> new JfrmPrestamo().setVisible(true));
    }

    // ── Declaración de variables (no modificar) ───────────────────────────────
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem JmItemAcercaDe;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JButton jbtCalculoAmort;
    private javax.swing.JButton jbtCalculosdePagos;
    private javax.swing.JComboBox<String> jcbIncremento;
    private javax.swing.JMenuItem jmItemAños;
    private javax.swing.JMenuItem jmItemInstruc;
    private javax.swing.JMenuItem jmItemMeses;
    private javax.swing.JMenuItem jmItemSalir;
    private javax.swing.JMenu jmOpciones;
    private javax.swing.JMenuBar jmnBar;
    private javax.swing.JMenu jmnuAyuda;
    private javax.swing.JMenu jmnuPrestamoEn;
    private javax.swing.JTable jtablaPrestamo;
    private javax.swing.JTextField jtfCredito;
    private javax.swing.JTextField jtfInteresMax;
    private javax.swing.JTextField jtfInteresMin;
    private javax.swing.JTextField jtfPeriodoMax;
    private javax.swing.JTextField jtfPeriodoMin;
    // End of variables declaration//GEN-END:variables

    // ── Utilidad de formato ───────────────────────────────────────────────────
    private String AlinDer(String formato, double valor) {
        return new java.text.DecimalFormat(formato).format(valor);
    }
}
